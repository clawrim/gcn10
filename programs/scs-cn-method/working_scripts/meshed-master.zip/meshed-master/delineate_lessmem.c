#define USE_LESS_MEMORY
#include "delineate_funcs.h"
